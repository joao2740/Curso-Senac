/**
 * SIMULAÇÃO DE FALHAS (Parte 4)
 * --------------------------------------------------------------
 * Este arquivo demonstra 3 falhas PROVOCADAS PROPOSITALMENTE para
 * comprovar que os testes detectam defeitos. Cada teste tem uma
 * versão "com falha" (comentada) e a versão corrigida.
 *
 * Para reproduzir as falhas durante a apresentação, troque o valor
 * esperado pelo indicado em /* FALHA *\/ e rode `npx vitest run`.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { screen } from '@testing-library/dom';
const { montarCardProduto } = require('../services/cardapioUI');
const { validarLogin, statusPedidoValido } = require('../services/validacoes');

const produto = {
    ID: 1, Nome: 'X-Burger', Descricao: 'Clássico',
    Categoria: 'lanches', Preco_Unitario: 28, disponivel: 1, destaque: 0,
};

describe('Simulação de Falhas', () => {
    beforeEach(() => {
        document.body.innerHTML = '<div id="menuContainer"></div>';
    });

    // FALHA 1 — Alterar texto esperado.
    // Versão com falha: expect(screen.getByText('Cheeseburger'))... -> texto não existe no DOM.
    it('FALHA-01: card exibe o nome correto do produto', () => {
        document.getElementById('menuContainer').innerHTML = montarCardProduto(produto);
        // /* FALHA */ expect(screen.getByText('Cheeseburger')).toBeInTheDocument();
        expect(screen.getByText('X-Burger')).toBeInTheDocument(); // CORRIGIDO
    });

    // FALHA 2 — Alterar resultado esperado de uma regra de negócio.
    // Versão com falha: expect(validarLogin('', '123').valido).toBe(true);
    it('FALHA-02: login sem e-mail é inválido', () => {
        // /* FALHA */ expect(validarLogin('', '123').valido).toBe(true);
        expect(validarLogin('', '123').valido).toBe(false); // CORRIGIDO
    });

    // FALHA 3 — Alterar propriedade/valor esperado.
    // Versão com falha: expect(statusPedidoValido('finalizado')).toBe(true);
    it('FALHA-03: status inexistente é rejeitado', () => {
        // /* FALHA */ expect(statusPedidoValido('finalizado')).toBe(true);
        expect(statusPedidoValido('finalizado')).toBe(false); // CORRIGIDO
    });
});
