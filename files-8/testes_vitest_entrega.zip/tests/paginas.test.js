/**
 * TESTES DE PÁGINAS (5)
 * --------------------------------------------------------------
 * Validam o comportamento de páginas completas montadas no DOM:
 * - página de cardápio renderizando lista de produtos da API
 * - página de cardápio ocultando indisponíveis
 * - estrutura do formulário da página de Login
 * - estrutura do formulário da página de Cadastro
 * - página de cardápio vazia (sem produtos)
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { screen } from '@testing-library/dom';
const { renderizarCardapio } = require('../services/cardapioUI');

const produtos = [
    { ID: 1, Nome: 'X-Burger', Descricao: 'Clássico', Categoria: 'lanches', Preco_Unitario: 28, disponivel: 1, destaque: 1 },
    { ID: 2, Nome: 'Batata Frita', Descricao: 'Porção', Categoria: 'acompanhamentos', Preco_Unitario: 15, disponivel: 1, destaque: 0 },
    { ID: 3, Nome: 'Refrigerante', Descricao: 'Lata 350ml', Categoria: 'bebidas', Preco_Unitario: 6, disponivel: 0, destaque: 0 },
];

describe('Página: Cardápio', () => {
    let container;
    beforeEach(() => {
        document.body.innerHTML = '<main><div id="menuContainer"></div></main>';
        container = document.getElementById('menuContainer');
    });

    // CT04 / cardápio público
    it('CT-PAG-01: renderiza todos os produtos disponíveis vindos da API', () => {
        renderizarCardapio(container, produtos);
        // 3 produtos, mas 1 indisponível => 2 cards
        expect(container.querySelectorAll('.menu-item').length).toBe(2);
        expect(screen.getByText('X-Burger')).toBeInTheDocument();
        expect(screen.getByText('Batata Frita')).toBeInTheDocument();
    });

    it('CT-PAG-02: não exibe produto indisponível na página', () => {
        renderizarCardapio(container, produtos);
        expect(screen.queryByText('Refrigerante')).not.toBeInTheDocument();
    });

    it('CT-PAG-03: exibe estado vazio quando não há produtos', () => {
        renderizarCardapio(container, []);
        expect(container.querySelectorAll('.menu-item').length).toBe(0);
        expect(container.innerHTML.trim()).toBe('');
    });
});

describe('Página: Login', () => {
    beforeEach(() => {
        // Estrutura equivalente ao formulário real de public/login.html
        document.body.innerHTML = `
            <form id="formLogin">
                <input type="email" id="emailLogin" />
                <input type="password" id="senhaLogin" />
                <button type="submit" id="btnEntrar">Entrar</button>
            </form>`;
    });

    it('CT-PAG-04: a página de login possui os campos de e-mail, senha e botão de entrar', () => {
        expect(document.getElementById('emailLogin')).toBeInTheDocument();
        expect(document.getElementById('senhaLogin')).toBeInTheDocument();
        expect(document.getElementById('emailLogin').type).toBe('email');
        expect(document.getElementById('senhaLogin').type).toBe('password');
        expect(screen.getByText('Entrar')).toBeInTheDocument();
    });
});

describe('Página: Cadastro', () => {
    beforeEach(() => {
        document.body.innerHTML = `
            <form id="formCadastro">
                <input id="nomeCadastro" />
                <input type="email" id="emailCadastro" />
                <input id="cpfCadastro" />
                <input id="telefoneCadastro" />
                <input type="password" id="senhaCadastro" />
                <input type="password" id="confirmarSenha" />
                <button type="submit">Cadastrar</button>
            </form>`;
    });

    it('CT-PAG-05: a página de cadastro possui todos os campos obrigatórios', () => {
        ['nomeCadastro', 'emailCadastro', 'cpfCadastro', 'telefoneCadastro', 'senhaCadastro', 'confirmarSenha']
            .forEach((id) => expect(document.getElementById(id)).toBeInTheDocument());
        expect(screen.getByText('Cadastrar')).toBeInTheDocument();
    });
});
