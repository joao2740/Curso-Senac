# Testes Automatizados — PI Cardápio QR Code

Suíte de testes automatizados com **Vitest** + **@testing-library/dom** + **jsdom**.

> Observação: o projeto é Node.js/Express + HTML (não React). Por isso usamos
> `@testing-library/dom` no lugar de `@testing-library/react`. Nenhum componente
> fictício foi criado — as funções testadas foram extraídas da lógica real do
> sistema para os módulos `services/validacoes.js` e `services/cardapioUI.js`.

## Como rodar

```bash
npm install           # instala dependências
npm run test:run      # executa todos os testes uma vez
npm run coverage      # executa com relatório de cobertura
npm test              # modo watch
```

## Estrutura

| Arquivo | Categoria | Qtd |
|---|---|---|
| `tests/componentes.test.js` | Componentes | 5 |
| `tests/paginas.test.js` | Páginas | 5 |
| `tests/integracao.test.js` | Integração | 5 |
| `tests/interacao.test.js` | Interação (userEvent) | 5 |
| `tests/regrasNegocio.test.js` | Regras de negócio (unitário) | 23 |
| `tests/simulacaoFalhas.test.js` | Simulação de falhas (Parte 4) | 3 |

**Total: 46 testes.**

## Módulos testados (lógica real extraída)

- `services/validacoes.js` — validação de login/cadastro, status de pedido,
  controle de acesso por perfil (verificarRole), formatação de preço,
  cálculo de total do carrinho e validação de pedido.
- `services/cardapioUI.js` — montagem do card de produto, renderização do
  cardápio e filtro por categoria (extraído de `public/cardapioSemLogin.html`).

## Cobertura obtida

| Métrica | Meta | Obtido |
|---|---|---|
| Statements | 60% | 100% |
| Functions | 60% | 100% |
| Lines | 60% | 100% |
| Branches | — | 95,9% |

## Simulação de falhas (Parte 4)

O arquivo `tests/simulacaoFalhas.test.js` documenta 3 falhas provocadas
propositalmente (texto esperado, resultado esperado e propriedade esperada).
As linhas marcadas com `/* FALHA */` mostram como reproduzir o erro; a versão
versionada está corrigida e passando.
