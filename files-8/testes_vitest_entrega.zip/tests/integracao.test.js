/**
 * TESTES DE INTEGRAÇÃO (5)
 * --------------------------------------------------------------
 * Validam fluxos que integram regras de negócio + interface,
 * simulando o comportamento do backend (server.js) e middlewares
 * sem depender do banco MySQL real.
 *
 * Fluxos cobertos:
 *  - Login: validação -> determinação de role -> controle de acesso
 *  - Cadastro: validação -> resposta de status
 *  - Cardápio: API (mock) -> renderização na página
 *  - Pedido: carrinho -> cálculo de total -> validação do pedido
 *  - Controle de acesso por perfil (verificarRole)
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
const {
    validarLogin,
    validarCadastro,
    determinarTipoPorCargo,
    podeAcessar,
    calcularTotalCarrinho,
    pedidoValido,
} = require('../services/validacoes');
const { renderizarCardapio } = require('../services/cardapioUI');

describe('Integração: Fluxo de Login + Controle de Acesso', () => {
    // CT01 Login -> CT (dashboard / role)
    it('CT-INT-01: gerente autenticado pode acessar o dashboard (login -> role -> acesso)', () => {
        const credenciais = validarLogin('gerente@burger.com', 'senha123');
        expect(credenciais.valido).toBe(true);

        const tipo = determinarTipoPorCargo('Gerente');
        expect(tipo).toBe('gerente');

        // /dashboard aceita funcionario ou gerente
        expect(podeAcessar(tipo, ['funcionario', 'gerente'])).toBe(true);
        // /menugerente aceita apenas gerente
        expect(podeAcessar(tipo, 'gerente')).toBe(true);
    });

    it('CT-INT-02: cliente NÃO acessa rotas exclusivas de gerente', () => {
        const tipo = 'cliente';
        expect(podeAcessar(tipo, 'gerente')).toBe(false);
        expect(podeAcessar(tipo, ['funcionario', 'gerente'])).toBe(false);
        // mas pode acessar o cardápio de cliente
        expect(podeAcessar(tipo, 'cliente')).toBe(true);
    });
});

describe('Integração: Fluxo de Cadastro', () => {
    it('CT-INT-03: cadastro válido segue para criação (status 201)', () => {
        const r = validarCadastro({
            nome: 'João', email: 'joao@email.com', cpf: '12345678900',
            telefone: '61999999999', senha: 'abc123', confirmaSenha: 'abc123',
        });
        expect(r.valido).toBe(true);
        expect(r.status).toBe(201);
    });
});

describe('Integração: API de produtos -> Página de cardápio', () => {
    beforeEach(() => {
        document.body.innerHTML = '<div id="menuContainer"></div>';
    });

    it('CT-INT-04: produtos retornados pela API (mock) são renderizados no cardápio', async () => {
        // Simula a resposta de GET /public/produtos
        const respostaApi = {
            status: 'success',
            data: [
                { ID: 1, Nome: 'X-Salada', Descricao: 'Com alface', Categoria: 'lanches', Preco_Unitario: 30, disponivel: 1, destaque: 0 },
                { ID: 2, Nome: 'Suco', Descricao: 'Laranja', Categoria: 'bebidas', Preco_Unitario: 10, disponivel: 1, destaque: 0 },
            ],
        };
        global.fetch = vi.fn().mockResolvedValue({
            json: async () => respostaApi,
        });

        // Reproduz o consumo de API feito em carregarCardapio()
        const response = await fetch('/public/produtos');
        const result = await response.json();
        const produtos = result.data || result;

        const container = document.getElementById('menuContainer');
        renderizarCardapio(container, produtos);

        expect(global.fetch).toHaveBeenCalledWith('/public/produtos');
        expect(container.querySelectorAll('.menu-item').length).toBe(2);
    });
});

describe('Integração: Carrinho -> Pedido', () => {
    it('CT-INT-05: carrinho calcula total e gera pedido válido', () => {
        const itens = [
            { id: 1, price: 28, quantity: 2 }, // 56
            { id: 2, price: 15, quantity: 1 }, // 15
        ];
        const total = calcularTotalCarrinho(itens);
        expect(total).toBe(71);

        const pedido = { itens, total, formaPagamento: 'pix', tipoPedido: 'delivery' };
        expect(pedidoValido(pedido)).toBe(true);
    });
});
