/**
 * TESTES DE COMPONENTES (5)
 * --------------------------------------------------------------
 * Validam os elementos de interface gerados pelo cardápio:
 * card de produto, selo de destaque, botão de adicionar, preço
 * formatado e ocultação de produtos indisponíveis.
 *
 * Usa @testing-library/dom para inspecionar o DOM real renderizado.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { screen, within } from '@testing-library/dom';
const { montarCardProduto, renderizarCardapio } = require('../services/cardapioUI');

const produtoBase = {
    ID: 1,
    Nome: 'X-Burger',
    Descricao: 'Hambúrguer artesanal',
    Categoria: 'lanches',
    Preco_Unitario: 28.0,
    imagem: 'xburger.jpg',
    disponivel: 1,
    destaque: 0,
};

let container;
beforeEach(() => {
    document.body.innerHTML = '<div id="menuContainer"></div>';
    container = document.getElementById('menuContainer');
});

describe('Componente: Card de Produto', () => {
    // CT07 - Componente de card de produto
    it('CT-COMP-01: renderiza o card com nome e descrição do produto', () => {
        container.innerHTML = montarCardProduto(produtoBase);
        expect(screen.getByText('X-Burger')).toBeInTheDocument();
        expect(screen.getByText('Hambúrguer artesanal')).toBeInTheDocument();
    });

    // Componente: preço formatado em BRL
    it('CT-COMP-02: exibe o preço formatado em Real (R$)', () => {
        container.innerHTML = montarCardProduto(produtoBase);
        const preco = container.querySelector('.price').textContent;
        // Aceita espaço normal ou non-breaking space usado pelo Intl
        expect(preco.replace(/\u00a0/g, ' ')).toBe('R$ 28,00');
    });

    // Componente: botão de adicionar
    it('CT-COMP-03: renderiza o botão de adicionar com o id do produto', () => {
        container.innerHTML = montarCardProduto(produtoBase);
        const botao = container.querySelector('.btn-add');
        expect(botao).toBeInTheDocument();
        expect(botao.getAttribute('data-id')).toBe('1');
    });

    // Componente: selo de destaque condicional
    it('CT-COMP-04: exibe o selo "Destaque" apenas quando destaque é verdadeiro', () => {
        container.innerHTML = montarCardProduto({ ...produtoBase, destaque: 1 });
        expect(screen.getByText('Destaque')).toBeInTheDocument();

        container.innerHTML = montarCardProduto({ ...produtoBase, destaque: 0 });
        expect(screen.queryByText('Destaque')).not.toBeInTheDocument();
    });

    // Componente: produto indisponível não é renderizado
    it('CT-COMP-05: não renderiza card de produto indisponível', () => {
        renderizarCardapio(container, [{ ...produtoBase, disponivel: 0 }]);
        expect(container.querySelectorAll('.menu-item').length).toBe(0);
    });
});
