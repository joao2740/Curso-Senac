/**
 * TESTES DE REGRAS DE NEGÓCIO (unitários)
 * --------------------------------------------------------------
 * Cobrem diretamente as funções de validação e regras do sistema,
 * garantindo a cobertura mínima exigida e validando os limites
 * (campos faltando, senhas divergentes, status inválido, etc.).
 */
import { describe, it, expect } from 'vitest';
const {
    validarLogin,
    validarCadastro,
    statusPedidoValido,
    determinarTipoPorCargo,
    podeAcessar,
    formatarPreco,
    calcularTotalCarrinho,
    pedidoValido,
    STATUS_PEDIDO_PERMITIDOS,
} = require('../services/validacoes');

describe('Regra: validarLogin', () => {
    it('rejeita quando email está ausente', () => {
        expect(validarLogin('', 'senha').valido).toBe(false);
    });
    it('rejeita quando senha está ausente', () => {
        expect(validarLogin('a@a.com', '').valido).toBe(false);
    });
    it('aceita quando email e senha estão presentes', () => {
        expect(validarLogin('a@a.com', '123').valido).toBe(true);
    });
});

describe('Regra: validarCadastro', () => {
    const completo = {
        nome: 'A', email: 'a@a.com', cpf: '1', telefone: '9',
        senha: 'x', confirmaSenha: 'x',
    };
    it('rejeita (400) quando falta um campo obrigatório', () => {
        const r = validarCadastro({ ...completo, telefone: '' });
        expect(r.valido).toBe(false);
        expect(r.status).toBe(400);
    });
    it('rejeita (406) quando as senhas não coincidem', () => {
        const r = validarCadastro({ ...completo, confirmaSenha: 'outra' });
        expect(r.valido).toBe(false);
        expect(r.status).toBe(406);
    });
    it('aceita (201) quando tudo está correto', () => {
        expect(validarCadastro(completo).status).toBe(201);
    });
});

describe('Regra: status de pedido', () => {
    it.each(STATUS_PEDIDO_PERMITIDOS)('aceita o status válido "%s"', (s) => {
        expect(statusPedidoValido(s)).toBe(true);
    });
    it('rejeita status inválido', () => {
        expect(statusPedidoValido('finalizado')).toBe(false);
    });
});

describe('Regra: determinarTipoPorCargo', () => {
    it('retorna "gerente" para cargo Gerente (case-insensitive)', () => {
        expect(determinarTipoPorCargo('Gerente')).toBe('gerente');
        expect(determinarTipoPorCargo('GERENTE')).toBe('gerente');
    });
    it('retorna "funcionario" para outros cargos', () => {
        expect(determinarTipoPorCargo('Atendente')).toBe('funcionario');
        expect(determinarTipoPorCargo(null)).toBe('funcionario');
    });
});

describe('Regra: podeAcessar', () => {
    it('aceita string única de role', () => {
        expect(podeAcessar('gerente', 'gerente')).toBe(true);
    });
    it('aceita array de roles', () => {
        expect(podeAcessar('funcionario', ['funcionario', 'gerente'])).toBe(true);
    });
    it('nega quando o tipo não está na lista', () => {
        expect(podeAcessar('cliente', ['gerente'])).toBe(false);
    });
});

describe('Regra: formatarPreco', () => {
    it('formata número como moeda BRL', () => {
        expect(formatarPreco(28).replace(/\u00a0/g, ' ')).toBe('R$ 28,00');
        expect(formatarPreco(5.5).replace(/\u00a0/g, ' ')).toBe('R$ 5,50');
    });
});

describe('Regra: calcularTotalCarrinho', () => {
    it('soma preço x quantidade dos itens', () => {
        expect(calcularTotalCarrinho([{ price: 10, quantity: 2 }, { price: 5, quantity: 3 }])).toBe(35);
    });
    it('retorna 0 para entrada inválida', () => {
        expect(calcularTotalCarrinho(null)).toBe(0);
        expect(calcularTotalCarrinho([])).toBe(0);
    });
});

describe('Regra: pedidoValido', () => {
    it('aceita pedido completo', () => {
        expect(pedidoValido({ itens: [{}], total: 10, formaPagamento: 'pix', tipoPedido: 'pickup' })).toBe(true);
    });
    it('rejeita pedido sem itens', () => {
        expect(pedidoValido({ itens: [], total: 10, formaPagamento: 'pix', tipoPedido: 'pickup' })).toBe(false);
    });
    it('rejeita pedido sem forma de pagamento', () => {
        expect(pedidoValido({ itens: [{}], total: 10, tipoPedido: 'pickup' })).toBe(false);
    });
});
