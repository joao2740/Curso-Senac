/**
 * TESTES DE INTERAÇÃO (5)
 * --------------------------------------------------------------
 * Usam @testing-library/user-event para simular o usuário real:
 * userEvent.type() (digitar) e userEvent.click() (clicar).
 *
 * Interações cobertas:
 *  - Preencher formulário de login (digitação)
 *  - Clique no botão de adicionar produto (carrinho)
 *  - Clique nos botões de filtro de categoria
 *  - Pesquisa de produto por palavra-chave (digitação + filtro)
 *  - Alternar visibilidade da senha (clique)
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import userEvent from '@testing-library/user-event';
import { screen } from '@testing-library/dom';
const { renderizarCardapio, filtrarPorCategoria } = require('../services/cardapioUI');

const produtos = [
    { ID: 1, Nome: 'X-Burger', Descricao: 'Clássico', Categoria: 'lanches', Preco_Unitario: 28, disponivel: 1, destaque: 0 },
    { ID: 2, Nome: 'Batata Frita', Descricao: 'Porção', Categoria: 'acompanhamentos', Preco_Unitario: 15, disponivel: 1, destaque: 0 },
    { ID: 3, Nome: 'Refrigerante', Descricao: 'Lata', Categoria: 'bebidas', Preco_Unitario: 6, disponivel: 1, destaque: 0 },
];

describe('Interação: Formulário de Login', () => {
    beforeEach(() => {
        document.body.innerHTML = `
            <form id="formLogin">
                <input type="email" id="emailLogin" />
                <input type="password" id="senhaLogin" />
            </form>`;
    });

    it('CT-ITR-01: usuário consegue digitar e-mail e senha no formulário', async () => {
        const user = userEvent.setup();
        const email = document.getElementById('emailLogin');
        const senha = document.getElementById('senhaLogin');

        await user.type(email, 'cliente@email.com');
        await user.type(senha, 'minhasenha');

        expect(email.value).toBe('cliente@email.com');
        expect(senha.value).toBe('minhasenha');
    });
});

describe('Interação: Botão de adicionar ao carrinho', () => {
    beforeEach(() => {
        document.body.innerHTML = '<div id="menuContainer"></div>';
        renderizarCardapio(document.getElementById('menuContainer'), produtos);
    });

    it('CT-ITR-02: clicar no botão "+" dispara a ação de adicionar o produto', async () => {
        const user = userEvent.setup();
        const adicionados = [];
        document.querySelectorAll('.btn-add').forEach((btn) => {
            btn.addEventListener('click', () => adicionados.push(btn.getAttribute('data-id')));
        });

        const primeiroBotao = document.querySelector('.btn-add');
        await user.click(primeiroBotao);

        expect(adicionados).toEqual(['1']);
    });
});

describe('Interação: Filtros de categoria', () => {
    beforeEach(() => {
        document.body.innerHTML = `
            <div>
                <button class="filter-btn" data-cat="todos">Todos</button>
                <button class="filter-btn" data-cat="lanches">Lanches</button>
                <button class="filter-btn" data-cat="bebidas">Bebidas</button>
            </div>
            <div id="menuContainer"></div>`;
        const container = document.getElementById('menuContainer');
        renderizarCardapio(container, produtos);

        document.querySelectorAll('.filter-btn').forEach((btn) => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('active'));
                btn.classList.add('active');
                filtrarPorCategoria(container, btn.getAttribute('data-cat'));
            });
        });
    });

    it('CT-ITR-03: clicar no filtro "Lanches" exibe somente lanches', async () => {
        const user = userEvent.setup();
        await user.click(screen.getByText('Lanches'));

        const visiveis = [...document.querySelectorAll('.menu-item')]
            .filter((i) => i.style.display !== 'none');
        expect(visiveis.length).toBe(1);
        expect(screen.getByText('Lanches').classList.contains('active')).toBe(true);
    });

    it('CT-ITR-04: clicar em "Todos" volta a exibir todos os produtos', async () => {
        const user = userEvent.setup();
        await user.click(screen.getByText('Bebidas'));
        await user.click(screen.getByText('Todos'));

        const visiveis = [...document.querySelectorAll('.menu-item')]
            .filter((i) => i.style.display !== 'none');
        expect(visiveis.length).toBe(3);
    });
});

describe('Interação: Pesquisa por palavra-chave', () => {
    beforeEach(() => {
        document.body.innerHTML = `
            <input id="busca" type="text" />
            <div id="menuContainer"></div>`;
        const container = document.getElementById('menuContainer');
        renderizarCardapio(container, produtos);

        document.getElementById('busca').addEventListener('input', (e) => {
            const termo = e.target.value.toLowerCase();
            container.querySelectorAll('.menu-item').forEach((item) => {
                const nome = item.querySelector('.item-title').textContent.toLowerCase();
                item.style.display = nome.includes(termo) ? 'block' : 'none';
            });
        });
    });

    it('CT-ITR-05: digitar "batata" filtra a lista para o produto correspondente', async () => {
        const user = userEvent.setup();
        await user.type(document.getElementById('busca'), 'batata');

        const visiveis = [...document.querySelectorAll('.menu-item')]
            .filter((i) => i.style.display !== 'none');
        expect(visiveis.length).toBe(1);
        expect(visiveis[0].querySelector('.item-title').textContent).toBe('Batata Frita');
    });
});
