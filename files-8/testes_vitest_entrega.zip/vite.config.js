import { defineConfig } from 'vite';

export default defineConfig({
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './setupTests.js',
    coverage: {
      provider: 'v8',
      reporter: ['text', 'text-summary', 'html'],
      // Mede a cobertura apenas dos módulos de lógica testados
      include: ['services/validacoes.js', 'services/cardapioUI.js'],
    },
  },
});
