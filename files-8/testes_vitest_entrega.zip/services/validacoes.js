/**
 * Módulo de validações e regras de negócio do sistema.
 *
 * Estas funções refletem regras já existentes no projeto (server.js):
 * - validação de campos obrigatórios de login/cadastro
 * - confirmação de senha no cadastro
 * - status permitidos de pedido (ENUM do banco)
 * - roles permitidas no controle de acesso (verificarRole)
 * - formatação de preço em BRL usada no cardápio
 *
 * Foram centralizadas aqui para permitir testes automatizados sem
 * depender do banco de dados ou do servidor Express em execução.
 */

// Status permitidos para um pedido (igual ao usado em PATCH /api/pedidos/:id/status)
const STATUS_PEDIDO_PERMITIDOS = ['novo', 'preparo', 'enviado', 'entregue', 'cancelado'];

// Tipos de usuário (roles) reconhecidos pelo sistema
const ROLES_VALIDAS = ['cliente', 'funcionario', 'gerente'];

/**
 * Valida os campos obrigatórios do login.
 * Espelha a regra de POST /login: email e senha são obrigatórios.
 * @returns {{ valido: boolean, mensagem: string|null }}
 */
function validarLogin(email, senha) {
    if (!email || !senha) {
        return { valido: false, mensagem: 'Email e senha são obrigatórios.' };
    }
    return { valido: true, mensagem: null };
}

/**
 * Valida os campos obrigatórios do cadastro de cliente.
 * Espelha a regra de POST /cadastro.
 * @returns {{ valido: boolean, status: number, mensagem: string|null }}
 */
function validarCadastro(dados) {
    const { nome, email, cpf, telefone, senha, confirmaSenha } = dados || {};

    if (!nome || !email || !cpf || !telefone || !senha || !confirmaSenha) {
        return {
            valido: false,
            status: 400,
            mensagem: 'Todos os dados (nome, email, CPF, telefone, senha) são necessários!'
        };
    }

    if (senha !== confirmaSenha) {
        return {
            valido: false,
            status: 406,
            mensagem: 'As senhas não estão condizentes'
        };
    }

    return { valido: true, status: 201, mensagem: null };
}

/**
 * Verifica se um status de pedido é permitido pelo sistema.
 */
function statusPedidoValido(status) {
    return STATUS_PEDIDO_PERMITIDOS.includes(status);
}

/**
 * Determina o tipo (role) do funcionário a partir do cargo.
 * Espelha a regra de POST /login: cargo 'gerente' => 'gerente', senão 'funcionario'.
 */
function determinarTipoPorCargo(cargo) {
    return (cargo && cargo.toLowerCase() === 'gerente') ? 'gerente' : 'funcionario';
}

/**
 * Verifica se um usuário com determinado tipo pode acessar um recurso.
 * Espelha a lógica do middleware verificarRole.
 * @param {string} tipoUsuario - tipo do usuário autenticado
 * @param {string|string[]} rolesPermitidos - role(s) permitida(s)
 */
function podeAcessar(tipoUsuario, rolesPermitidos) {
    const roles = Array.isArray(rolesPermitidos) ? rolesPermitidos : [rolesPermitidos];
    return roles.includes(tipoUsuario);
}

/**
 * Formata um valor numérico como moeda brasileira (BRL).
 * Espelha a formatação usada em carregarCardapio() no cardápio.
 */
function formatarPreco(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

/**
 * Calcula o total de um carrinho de itens { price, quantity }.
 * Regra de negócio usada na criação de pedidos.
 */
function calcularTotalCarrinho(itens) {
    if (!Array.isArray(itens)) return 0;
    return itens.reduce((total, item) => {
        const preco = Number(item.price) || 0;
        const qtd = Number(item.quantity) || 0;
        return total + preco * qtd;
    }, 0);
}

/**
 * Valida se os dados mínimos de um pedido estão presentes.
 * Espelha a regra de POST /api/pedidos.
 */
function pedidoValido(pedido) {
    const { itens, total, formaPagamento, tipoPedido } = pedido || {};
    if (!itens || !itens.length || !total || !formaPagamento || !tipoPedido) {
        return false;
    }
    return true;
}

module.exports = {
    STATUS_PEDIDO_PERMITIDOS,
    ROLES_VALIDAS,
    validarLogin,
    validarCadastro,
    statusPedidoValido,
    determinarTipoPorCargo,
    podeAcessar,
    formatarPreco,
    calcularTotalCarrinho,
    pedidoValido,
};
