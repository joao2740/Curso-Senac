/**
 * Funções de interface (DOM) extraídas da página de cardápio
 * (public/cardapioSemLogin.html).
 *
 * Reproduzem fielmente o comportamento real do sistema:
 * - renderização dos cards de produto a partir dos dados da API
 * - ocultação de produtos indisponíveis (disponivel == 0)
 * - exibição do selo "Destaque"
 * - filtragem por categoria
 *
 * Centralizadas aqui para permitir testes de componentes/interface
 * com @testing-library/dom + jsdom, sem depender do Bootstrap nem
 * de um servidor em execução.
 */

const { formatarPreco } = require('./validacoes');

/**
 * Cria o HTML de um único card de produto (igual ao gerado em carregarCardapio()).
 * @param {object} produto
 * @returns {string} HTML do card, ou '' se o produto estiver indisponível.
 */
function montarCardProduto(produto) {
    if (produto.disponivel == 0) {
        return '';
    }

    const precoFormatado = formatarPreco(produto.Preco_Unitario);
    const destaque = produto.destaque
        ? '<span class="badge bg-warning text-dark">Destaque</span>'
        : '';

    return `
    <div class="col-md-6 col-lg-3 menu-item" data-category="${produto.Categoria || 'geral'}">
        <div class="menu-card">
            <img src="${produto.imagem || 'imagem-padrao.jpg'}" class="thumb" alt="${produto.Nome}">
            <div class="card-body">
                <h4 class="item-title">${produto.Nome}</h4>
                <p class="item-desc">${produto.Descricao}</p>
                ${destaque}
                <div class="card-footer-custom">
                    <span class="price">${precoFormatado}</span>
                    <button class="btn-add" data-id="${produto.ID}">+</button>
                </div>
            </div>
        </div>
    </div>`;
}

/**
 * Renderiza a lista de produtos dentro de um container.
 * Produtos indisponíveis não são renderizados.
 * @param {HTMLElement} container
 * @param {object[]} produtos
 */
function renderizarCardapio(container, produtos) {
    container.innerHTML = '';
    produtos.forEach((produto) => {
        container.innerHTML += montarCardProduto(produto);
    });
}

/**
 * Aplica o filtro de categoria, mostrando/ocultando os .menu-item.
 * Espelha filterMenu() (sem as animações/timeouts).
 * @param {HTMLElement} container
 * @param {string} categoria - 'todos' ou nome da categoria
 */
function filtrarPorCategoria(container, categoria) {
    const itens = container.querySelectorAll('.menu-item');
    itens.forEach((item) => {
        if (categoria === 'todos' || item.getAttribute('data-category') === categoria) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

module.exports = {
    montarCardProduto,
    renderizarCardapio,
    filtrarPorCategoria,
};
