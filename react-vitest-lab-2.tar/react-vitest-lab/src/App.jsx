import Hero from "./sections/Hero";
import Areas from "./sections/Areas";
import Sobre from "./sections/Sobre";
import FormContato from "./components/FormContato";

function Header() {
  return (
    <header>
      <p>Silva & Associados</p>
      <nav aria-label="menu principal">
        <a href="#areas">Áreas</a>
        <a href="#sobre">Sobre</a>
        <a href="#contato">Contato</a>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer>
      <p>© 2025 Silva & Associados. Todos os direitos reservados.</p>
    </footer>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Areas />
        <Sobre />
        <section aria-label="formulário de contato">
          <h2>Entre em Contato</h2>
          <FormContato />
        </section>
      </main>
      <Footer />
    </>
  );
}
