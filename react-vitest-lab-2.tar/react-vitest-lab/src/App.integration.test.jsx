import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "./App";

describe("App — Integração", () => {
  describe("Estrutura da página", () => {
    it("exibe todos os elementos principais da landing page", () => {
      render(<App />);

      // Header
      const header = screen.getByRole("banner");
      expect(within(header).getByText(/silva & associados/i)).toBeInTheDocument();
      expect(screen.getByRole("navigation", { name: /menu principal/i })).toBeInTheDocument();

      // Hero
      expect(
        screen.getByRole("heading", { name: /escritório jurídico silva & associados/i })
      ).toBeInTheDocument();

      // Áreas
      expect(screen.getByRole("heading", { name: /áreas de atuação/i })).toBeInTheDocument();

      // Sobre
      expect(screen.getByRole("heading", { name: /sobre nós/i })).toBeInTheDocument();

      // Formulário
      expect(screen.getByLabelText(/nome/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/mensagem/i)).toBeInTheDocument();

      // Footer
      expect(screen.getByText(/todos os direitos reservados/i)).toBeInTheDocument();
    });
  });

  describe("Fluxo completo do usuário", () => {
    it("preenche e envia o formulário com sucesso", async () => {
      render(<App />);

      await userEvent.type(screen.getByLabelText(/nome/i), "Pedro Alves");
      await userEvent.type(screen.getByLabelText(/email/i), "pedro@email.com");
      await userEvent.type(
        screen.getByLabelText(/mensagem/i),
        "Preciso de orientação sobre meu contrato de trabalho."
      );

      await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

      expect(screen.getByText("Mensagem enviada com sucesso")).toBeInTheDocument();
    });

    it("limpa os campos do formulário após envio com sucesso", async () => {
      render(<App />);

      await userEvent.type(screen.getByLabelText(/nome/i), "Pedro Alves");
      await userEvent.type(screen.getByLabelText(/email/i), "pedro@email.com");
      await userEvent.type(
        screen.getByLabelText(/mensagem/i),
        "Preciso de orientação sobre meu contrato de trabalho."
      );

      await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

      expect(screen.getByLabelText(/nome/i)).toHaveValue("");
      expect(screen.getByLabelText(/email/i)).toHaveValue("");
      expect(screen.getByLabelText(/mensagem/i)).toHaveValue("");
    });
  });
});
