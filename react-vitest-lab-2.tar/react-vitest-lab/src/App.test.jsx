import { render, screen, within } from "@testing-library/react";
import App from "./App";

describe("App", () => {
  it("exibe o nome do escritório no header", () => {
    render(<App />);
    const header = screen.getByRole("banner");
    expect(within(header).getByText(/silva & associados/i)).toBeInTheDocument();
  });

  it("exibe o menu de navegação principal", () => {
    render(<App />);
    expect(screen.getByRole("navigation", { name: /menu principal/i })).toBeInTheDocument();
  });

  it("exibe o título principal no Hero", () => {
    render(<App />);
    expect(
      screen.getByRole("heading", { name: /escritório jurídico silva & associados/i })
    ).toBeInTheDocument();
  });

  it("exibe a seção de áreas de atuação", () => {
    render(<App />);
    expect(screen.getByRole("heading", { name: /áreas de atuação/i })).toBeInTheDocument();
  });

  it("exibe a seção sobre o escritório", () => {
    render(<App />);
    expect(screen.getByRole("heading", { name: /sobre nós/i })).toBeInTheDocument();
  });

  it("exibe o formulário de contato", () => {
    render(<App />);
    expect(screen.getByLabelText(/nome/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/mensagem/i)).toBeInTheDocument();
  });

  it("exibe o footer", () => {
    render(<App />);
    expect(
      screen.getByText(/todos os direitos reservados/i)
    ).toBeInTheDocument();
  });
});
