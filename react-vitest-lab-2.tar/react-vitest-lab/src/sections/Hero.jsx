export default function Hero() {
  return (
    <section aria-label="hero">
      <h1>Escritório Jurídico Silva & Associados</h1>
      <p>Defendendo seus direitos com excelência e dedicação</p>
    </section>
  );
}
