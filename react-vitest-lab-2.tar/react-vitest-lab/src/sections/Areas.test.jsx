import { render, screen } from "@testing-library/react";
import Areas from "./Areas";

describe("Areas", () => {
  it("exibe o título da seção", () => {
    render(<Areas />);
    expect(screen.getByRole("heading", { name: /áreas de atuação/i })).toBeInTheDocument();
  });

  it("lista as áreas de atuação", () => {
    render(<Areas />);
    expect(screen.getByText("Direito Civil")).toBeInTheDocument();
    expect(screen.getByText("Direito Trabalhista")).toBeInTheDocument();
    expect(screen.getByText("Direito de Família")).toBeInTheDocument();
    expect(screen.getByText("Direito Empresarial")).toBeInTheDocument();
  });
});
