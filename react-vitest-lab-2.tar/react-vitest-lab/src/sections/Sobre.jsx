export default function Sobre() {
  return (
    <section aria-label="sobre o escritório">
      <h2>Sobre Nós</h2>
      <p>
        Há mais de 20 anos atuando na defesa dos interesses de nossos clientes
        com ética, transparência e comprometimento.
      </p>
    </section>
  );
}
