import { render, screen } from "@testing-library/react";
import Sobre from "./Sobre";

describe("Sobre", () => {
  it("exibe o título da seção", () => {
    render(<Sobre />);
    expect(screen.getByRole("heading", { name: /sobre nós/i })).toBeInTheDocument();
  });

  it("exibe o texto de apresentação", () => {
    render(<Sobre />);
    expect(screen.getByText(/há mais de 20 anos/i)).toBeInTheDocument();
  });
});
