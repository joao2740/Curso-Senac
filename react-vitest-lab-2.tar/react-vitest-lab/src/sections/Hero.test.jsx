import { render, screen } from "@testing-library/react";
import Hero from "./Hero";

describe("Hero", () => {
  it("exibe o título principal", () => {
    render(<Hero />);
    expect(
      screen.getByRole("heading", { name: /escritório jurídico silva & associados/i })
    ).toBeInTheDocument();
  });

  it("exibe o subtítulo", () => {
    render(<Hero />);
    expect(
      screen.getByText(/defendendo seus direitos com excelência e dedicação/i)
    ).toBeInTheDocument();
  });
});
