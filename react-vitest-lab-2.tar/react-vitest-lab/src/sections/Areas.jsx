const areas = [
  "Direito Civil",
  "Direito Trabalhista",
  "Direito de Família",
  "Direito Empresarial",
];

export default function Areas() {
  return (
    <section aria-label="áreas de atuação">
      <h2>Áreas de Atuação</h2>
      <ul>
        {areas.map((area) => (
          <li key={area}>{area}</li>
        ))}
      </ul>
    </section>
  );
}
