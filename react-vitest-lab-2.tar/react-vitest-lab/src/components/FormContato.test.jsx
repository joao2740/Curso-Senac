import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import FormContato from "./FormContato";

describe("FormContato", () => {
  it("exibe erros ao enviar o formulário vazio", async () => {
    render(<FormContato />);
    await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

    expect(screen.getByText("Nome é obrigatório")).toBeInTheDocument();
    expect(screen.getByText("Email inválido")).toBeInTheDocument();
    expect(screen.getByText("Mensagem muito curta")).toBeInTheDocument();
  });

  it("exibe erro quando email não contém @", async () => {
    render(<FormContato />);
    await userEvent.type(screen.getByLabelText(/nome/i), "Maria");
    await userEvent.type(screen.getByLabelText(/email/i), "emailsemarroba.com");
    await userEvent.type(screen.getByLabelText(/mensagem/i), "Olá, preciso de ajuda.");
    await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

    expect(screen.getByText("Email inválido")).toBeInTheDocument();
  });

  it("exibe erro quando mensagem tem menos de 10 caracteres", async () => {
    render(<FormContato />);
    await userEvent.type(screen.getByLabelText(/nome/i), "João");
    await userEvent.type(screen.getByLabelText(/email/i), "joao@email.com");
    await userEvent.type(screen.getByLabelText(/mensagem/i), "Curta");
    await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

    expect(screen.getByText("Mensagem muito curta")).toBeInTheDocument();
  });

  it("exibe mensagem de sucesso quando tudo está correto", async () => {
    render(<FormContato />);
    await userEvent.type(screen.getByLabelText(/nome/i), "Ana Paula");
    await userEvent.type(screen.getByLabelText(/email/i), "ana@email.com");
    await userEvent.type(screen.getByLabelText(/mensagem/i), "Olá, gostaria de agendar uma consulta.");
    await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

    expect(screen.getByText("Mensagem enviada com sucesso")).toBeInTheDocument();
  });

  it("limpa os campos após envio com sucesso", async () => {
    render(<FormContato />);
    await userEvent.type(screen.getByLabelText(/nome/i), "Carlos");
    await userEvent.type(screen.getByLabelText(/email/i), "carlos@email.com");
    await userEvent.type(screen.getByLabelText(/mensagem/i), "Preciso de assessoria jurídica urgente.");
    await userEvent.click(screen.getByRole("button", { name: /enviar/i }));

    expect(screen.getByLabelText(/nome/i)).toHaveValue("");
    expect(screen.getByLabelText(/email/i)).toHaveValue("");
    expect(screen.getByLabelText(/mensagem/i)).toHaveValue("");
  });
});
