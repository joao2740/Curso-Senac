import { useState } from "react";

export default function FaqItem({ pergunta, resposta }) {
  const [aberto, setAberto] = useState(false);

  return (
    <div className="faq-item">
      <button onClick={() => setAberto(!aberto)}>
        {pergunta}
      </button>
      {aberto && <p>{resposta}</p>}
    </div>
  );
}
