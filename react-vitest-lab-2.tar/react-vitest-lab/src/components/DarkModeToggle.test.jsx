import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import DarkModeToggle from "./DarkModeToggle";

describe("DarkModeToggle", () => {
  afterEach(() => {
    document.body.removeAttribute("data-tema");
    document.body.classList.remove("dark");
  });

  it("começa no tema claro com texto 'Tema Escuro'", () => {
    render(<DarkModeToggle />);
    expect(screen.getByRole("button", { name: /tema escuro/i })).toBeInTheDocument();
  });

  it("muda o texto para 'Tema Claro' ao clicar", async () => {
    render(<DarkModeToggle />);
    await userEvent.click(screen.getByRole("button"));
    expect(screen.getByRole("button", { name: /tema claro/i })).toBeInTheDocument();
  });

  it("volta ao texto 'Tema Escuro' ao clicar novamente", async () => {
    render(<DarkModeToggle />);
    await userEvent.click(screen.getByRole("button"));
    await userEvent.click(screen.getByRole("button"));
    expect(screen.getByRole("button", { name: /tema escuro/i })).toBeInTheDocument();
  });

  it("aplica o atributo data-tema='escuro' ao body após primeiro clique", async () => {
    render(<DarkModeToggle />);
    await userEvent.click(screen.getByRole("button"));
    expect(document.body).toHaveAttribute("data-tema", "escuro");
  });

  it("aplica a classe 'dark' ao body após primeiro clique", async () => {
    render(<DarkModeToggle />);
    await userEvent.click(screen.getByRole("button"));
    expect(document.body).toHaveClass("dark");
  });

  it("remove a classe 'dark' ao voltar ao tema claro", async () => {
    render(<DarkModeToggle />);
    await userEvent.click(screen.getByRole("button"));
    await userEvent.click(screen.getByRole("button"));
    expect(document.body).not.toHaveClass("dark");
  });

  it("o botão reflete o estado pressionado via aria-pressed", async () => {
    render(<DarkModeToggle />);
    const btn = screen.getByRole("button");
    expect(btn).toHaveAttribute("aria-pressed", "false");
    await userEvent.click(btn);
    expect(btn).toHaveAttribute("aria-pressed", "true");
  });
});
