import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import FaqItem from "./FaqItem";

describe("FaqItem", () => {
  const pergunta = "O escritório atende online?";
  const resposta = "Sim, atendemos clientes em todo o Brasil.";

  it("exibe a pergunta na tela", () => {
    render(<FaqItem pergunta={pergunta} resposta={resposta} />);
    expect(screen.getByText(pergunta)).toBeInTheDocument();
  });

  it("não exibe a resposta inicialmente", () => {
    render(<FaqItem pergunta={pergunta} resposta={resposta} />);
    expect(screen.queryByText(resposta)).not.toBeInTheDocument();
  });

  it("exibe a resposta após clicar na pergunta", async () => {
    render(<FaqItem pergunta={pergunta} resposta={resposta} />);
    await userEvent.click(screen.getByText(pergunta));
    expect(screen.getByText(resposta)).toBeInTheDocument();
  });

  it("esconde a resposta ao clicar novamente", async () => {
    render(<FaqItem pergunta={pergunta} resposta={resposta} />);
    await userEvent.click(screen.getByText(pergunta));
    await userEvent.click(screen.getByText(pergunta));
    expect(screen.queryByText(resposta)).not.toBeInTheDocument();
  });
});
