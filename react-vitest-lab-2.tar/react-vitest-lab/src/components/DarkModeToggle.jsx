import { useState } from "react";

export default function DarkModeToggle() {
  const [escuro, setEscuro] = useState(false);

  function alternar() {
    setEscuro((prev) => !prev);
    document.body.setAttribute("data-tema", escuro ? "claro" : "escuro");
    document.body.classList.toggle("dark", !escuro);
  }

  return (
    <button onClick={alternar} aria-pressed={escuro}>
      {escuro ? "Tema Claro" : "Tema Escuro"}
    </button>
  );
}
