import { useState } from "react";

const estadoInicial = { nome: "", email: "", mensagem: "" };

export default function FormContato() {
  const [campos, setCampos] = useState(estadoInicial);
  const [erros, setErros] = useState({});
  const [sucesso, setSucesso] = useState(false);

  function validar() {
    const novosErros = {};

    if (!campos.nome.trim()) {
      novosErros.nome = "Nome é obrigatório";
    }

    if (!campos.email.trim() || !campos.email.includes("@")) {
      novosErros.email = "Email inválido";
    }

    if (!campos.mensagem.trim() || campos.mensagem.trim().length < 10) {
      novosErros.mensagem = "Mensagem muito curta";
    }

    return novosErros;
  }

  function handleChange(e) {
    const { name, value } = e.target;
    setCampos((prev) => ({ ...prev, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    const novosErros = validar();

    if (Object.keys(novosErros).length > 0) {
      setErros(novosErros);
      setSucesso(false);
      return;
    }

    setErros({});
    setSucesso(true);
    setCampos(estadoInicial);
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div>
        <label htmlFor="nome">Nome</label>
        <input
          id="nome"
          name="nome"
          type="text"
          value={campos.nome}
          onChange={handleChange}
        />
        {erros.nome && <span role="alert">{erros.nome}</span>}
      </div>

      <div>
        <label htmlFor="email">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          value={campos.email}
          onChange={handleChange}
        />
        {erros.email && <span role="alert">{erros.email}</span>}
      </div>

      <div>
        <label htmlFor="mensagem">Mensagem</label>
        <textarea
          id="mensagem"
          name="mensagem"
          value={campos.mensagem}
          onChange={handleChange}
        />
        {erros.mensagem && <span role="alert">{erros.mensagem}</span>}
      </div>

      <button type="submit">Enviar</button>

      {sucesso && <p role="status">Mensagem enviada com sucesso</p>}
    </form>
  );
}
